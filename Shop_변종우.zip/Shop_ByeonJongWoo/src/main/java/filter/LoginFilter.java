package filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter("/*")
public class LoginFilter extends HttpFilter implements Filter {
    
    // 데이터베이스 정보
    private static final String DB_URL = "jdbc:mysql://localhost:3306/joeun?serverTimezone=Asia/Seoul&allowPublicKeyRetrieval=true&useSSL=false";
    private static final String DB_USER = "joeun";
    private static final String DB_PASSWORD = "123456";
    
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request; // 형변환
        HttpServletResponse httpResponse = (HttpServletResponse) response; // 형변환
        HttpSession session = httpRequest.getSession();
        
        // 이미 로그인된 경우, 필터를 건너뜀
        if (session.getAttribute("loginId") != null) {
            chain.doFilter(request, response);
            return;
        }
        
        // 쿠키에서 "rememberMe"와 "token"을 가져옴
        String rememberMe = null;
        String token = null;
        Cookie[] cookies = httpRequest.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("rememberMe".equals(cookie.getName())) {
                    rememberMe = cookie.getValue();
                } else if ("token".equals(cookie.getName())) {
                    token = cookie.getValue();
                }
            }
        }
        
        // rememberMe와 token 쿠키가 존재하는 경우 자동 로그인 처리
        if ("true".equals(rememberMe) && token != null) {
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement pstmt = conn.prepareStatement("SELECT user_id FROM persistent_logins WHERE token = ?")) {
                
                pstmt.setString(1, token);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        // 로그인 ID를 세션에 저장
                        String loginId = rs.getString("user_id");
                        session.setAttribute("loginId", loginId);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        // 다음 필터 또는 요청으로 전달
        chain.doFilter(request, response);
    }
}
