package shop.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import shop.dto.Order;
import shop.dto.Product;

public class OrderRepository extends JDBConnection {

    /**
     * 주문 등록
     * @param order
     * @return
     */
    public int insert(Order order) {
        int result = 0;

        String sql = "INSERT INTO orders(cartId, shipName, zipCode, country, address, date, userId, totalPrice, phone, orderPw) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            psmt = con.prepareStatement(sql);
            psmt.setString(1, order.getCartId());
            psmt.setString(2, order.getShipName());
            psmt.setString(3, order.getZipCode());
            psmt.setString(4, order.getCountry());
            psmt.setString(5, order.getAddress());
            psmt.setString(6, order.getDate());
            psmt.setString(7, order.getUserId());
            psmt.setInt(8, order.getTotalPrice());
            psmt.setString(9, order.getPhone());
            psmt.setString(10, order.getOrderPw());
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("주문 등록 시, 예외 발생");
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 최근 등록한 orderNo
     * @return
     */
    public int lastOrderNo() {
        int orderNo = 0;
        String sql = "SELECT MAX(orderNo) AS lastOrderNo FROM orders";

        try {
            psmt = con.prepareStatement(sql);
            rs = psmt.executeQuery();
            if (rs.next()) {
                orderNo = rs.getInt("lastOrderNo");
            }
        } catch (SQLException e) {
            System.err.println("최신 주문 번호 조회 시, 예외 발생");
            e.printStackTrace();
        }
        return orderNo;
    }

    /**
     * 주문 내역 조회 - 회원
     * @param userId
     * @return
     */
    public List<Product> list(String userId) {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT p.* FROM products p "
                   + "JOIN orders o ON p.orderNo = o.orderNo "
                   + "WHERE o.userId = ?";

        try {
            psmt = con.prepareStatement(sql);
            psmt.setString(1, userId);
            rs = psmt.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setProductId(rs.getString("productId"));
                product.setName(rs.getString("name"));
                product.setUnitPrice(rs.getInt("unitPrice"));
                product.setDescription(rs.getString("description"));
                product.setManufacturer(rs.getString("manufacturer"));
                product.setCategory(rs.getString("category"));
                product.setUnitsInStock(rs.getLong("unitsInStock"));
                product.setCondition(rs.getString("condition"));
                product.setFile(rs.getString("file"));
                product.setQuantity(rs.getInt("quantity"));
                products.add(product);
            }
        } catch (SQLException e) {
            System.err.println("회원 주문 내역 조회 시, 예외 발생");
            e.printStackTrace();
        }
        return products;
    }

    /**
     * 주문 내역 조회 - 비회원
     * @param phone
     * @param orderPw
     * @return
     */
    public List<Product> list(String phone, String orderPw) {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT p.* FROM products p "
                   + "JOIN orders o ON p.orderNo = o.orderNo "
                   + "WHERE o.phone = ? AND o.orderPw = ?";

        try {
            psmt = con.prepareStatement(sql);
            psmt.setString(1, phone);
            psmt.setString(2, orderPw);
            rs = psmt.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setProductId(rs.getString("productId"));
                product.setName(rs.getString("name"));
                product.setUnitPrice(rs.getInt("unitPrice"));
                product.setDescription(rs.getString("description"));
                product.setManufacturer(rs.getString("manufacturer"));
                product.setCategory(rs.getString("category"));
                product.setUnitsInStock(rs.getLong("unitsInStock"));
                product.setCondition(rs.getString("condition"));
                product.setFile(rs.getString("file"));
                product.setQuantity(rs.getInt("quantity"));
                products.add(product);
            }
        } catch (SQLException e) {
            System.err.println("비회원 주문 내역 조회 시, 예외 발생");
            e.printStackTrace();
        }
        return products;
    }
}
