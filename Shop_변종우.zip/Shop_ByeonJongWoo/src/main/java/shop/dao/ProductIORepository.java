package shop.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import shop.dto.ProductIO;

public class ProductIORepository extends JDBConnection {

    /**
     * 상품 입출고 등록
     * @param productIO
     * @return
     */
    public int insert(ProductIO productIO) {
        int result = 0;
        String sql = "INSERT INTO product_io(product_id, order_no, amount, type, io_date, user_id) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        try {
            psmt = con.prepareStatement(sql);
            psmt.setString(1, productIO.getProductId());
            psmt.setInt(2, productIO.getOrderNo());
            psmt.setInt(3, productIO.getAmount());
            psmt.setString(4, productIO.getType());
            psmt.setTimestamp(5, productIO.getIoDate());
            psmt.setString(6, productIO.getUserId());
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("상품 입출고 등록 시, 예외 발생");
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 상품 입출고 내역 조회
     * @param ioNo
     * @return
     */
    public ProductIO select(int ioNo) {
        ProductIO productIO = null;
        String sql = "SELECT * FROM product_io WHERE io_no = ?";

        try {
            psmt = con.prepareStatement(sql);
            psmt.setInt(1, ioNo);
            rs = psmt.executeQuery();
            if (rs.next()) {
                productIO = new ProductIO();
                productIO.setIoNo(rs.getInt("io_no"));
                productIO.setProductId(rs.getString("product_id"));
                productIO.setOrderNo(rs.getInt("order_no"));
                productIO.setAmount(rs.getInt("amount"));
                productIO.setType(rs.getString("type"));
                productIO.setIoDate(rs.getTimestamp("io_date"));
                productIO.setUserId(rs.getString("user_id"));
            }
        } catch (SQLException e) {
            System.err.println("상품 입출고 내역 조회 시, 예외 발생");
            e.printStackTrace();
        }
        return productIO;
    }

    /**
     * 모든 상품 입출고 내역 조회
     * @return
     */
    public List<ProductIO> selectAll() {
        List<ProductIO> productIOList = new ArrayList<>();
        String sql = "SELECT * FROM product_io";

        try {
            psmt = con.prepareStatement(sql);
            rs = psmt.executeQuery();
            while (rs.next()) {
                ProductIO productIO = new ProductIO();
                productIO.setIoNo(rs.getInt("io_no"));
                productIO.setProductId(rs.getString("product_id"));
                productIO.setOrderNo(rs.getInt("order_no"));
                productIO.setAmount(rs.getInt("amount"));
                productIO.setType(rs.getString("type"));
                productIO.setIoDate(rs.getTimestamp("io_date"));
                productIO.setUserId(rs.getString("user_id"));
                productIOList.add(productIO);
            }
        } catch (SQLException e) {
            System.err.println("모든 상품 입출고 내역 조회 시, 예외 발생");
            e.printStackTrace();
        }
        return productIOList;
    }

    /**
     * 상품 입출고 수정
     * @param productIO
     * @return
     */
    public int update(ProductIO productIO) {
        int result = 0;
        String sql = "UPDATE product_io SET product_id = ?, order_no = ?, amount = ?, type = ?, io_date = ?, user_id = ? "
                   + "WHERE io_no = ?";

        try {
            psmt = con.prepareStatement(sql);
            psmt.setString(1, productIO.getProductId());
            psmt.setInt(2, productIO.getOrderNo());
            psmt.setInt(3, productIO.getAmount());
            psmt.setString(4, productIO.getType());
            psmt.setTimestamp(5, productIO.getIoDate());
            psmt.setString(6, productIO.getUserId());
            psmt.setInt(7, productIO.getIoNo());
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("상품 입출고 수정 시, 예외 발생");
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 상품 입출고 삭제
     * @param ioNo
     * @return
     */
    public int delete(int ioNo) {
        int result = 0;
        String sql = "DELETE FROM product_io WHERE io_no = ?";

        try {
            psmt = con.prepareStatement(sql);
            psmt.setInt(1, ioNo);
            result = psmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("상품 입출고 삭제 시, 예외 발생");
            e.printStackTrace();
        }
        return result;
    }
}
