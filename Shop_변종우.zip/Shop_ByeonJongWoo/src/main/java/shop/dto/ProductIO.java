package shop.dto;

/**
 * 상품 입출고 데이터
 */
public class ProductIO {

    private int ioNo;            // 입출고 번호
    private String productId;    // 상품 ID
    private int orderNo;         // 주문 번호
    private int amount;          // 수량
    private String type;         // 입출고 타입 (입고/출고)
    private java.sql.Timestamp ioDate; // 입출고 날짜
    private String userId;       // 사용자 ID

    public ProductIO() {
    }

    public int getIoNo() {
        return ioNo;
    }

    public void setIoNo(int ioNo) {
        this.ioNo = ioNo;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public int getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(int orderNo) {
        this.orderNo = orderNo;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public java.sql.Timestamp getIoDate() {
        return ioDate;
    }

    public void setIoDate(java.sql.Timestamp ioDate) {
        this.ioDate = ioDate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "ProductIO [ioNo=" + ioNo + ", productId=" + productId + ", orderNo=" + orderNo + ", amount=" + amount
                + ", type=" + type + ", ioDate=" + ioDate + ", userId=" + userId + "]";
    }
}
